#!/usr/bin/env ruby
#
# Plain Text Wiki (Redux)
# =======================
# Based on Matt Webb's [Plain Text Wiki][1].
# [1]: http://interconnected.org/home/2007/05/20/plain_text_wiki
#
# Run a simple wiki from inside your TextMate editor.
# Now with improved export facilities and better in-editor syntax
# highlighting!
#
# Features
# --------
# * Subdirectories -
#    Pages can live in subdirectories and are linked to using 
#    `[ [subdir/name] ]` style links (no space between first and second `[`) 
# * Named links -
#    Can use `[ [pagelink | link text] ]` to use `link text` instead of
#    link name when exporting to HTML.
# * Uses ERB for templates -
#    Templates can include `<%= property %>` to include page properties.
#    Currently, these include `title`, `modified`, `name`, `path_to_root`.
# * Page title can be overriden - 
#    Use HTML comments at very start of page. 
#    e.g., `<!-- title = My new page title -->`.
#
# Environment
# -----------
# The following environment variables can be set from within TextMate
# to control the behaviour of the wiki.
#
# * `WIKI_TEMPLATE_DIR` - 
#   Where to look to find `header.rhtml` and `footer.rhtml`. Defaults to 
#   `TM_BUNDLE_SUPPORT/templates`
# * `WIKI_EXPORT_EXCLUDE` -
#   Comma separated list of directories to exclude from export.
# 
# Future Work
# -----------
# * FIXME Page#modified only works when current directory is top-level
# * TODO Reinstate CamelCase as an option
# * TODO Reinstate the use of Textile as a Page format
# * TODO Make runnable from command line without TextMate
# * TODO Factor interaction, export and data store in separate files
#
# AUTHOR:   Mark Reid <mark@threewordslong.com>
# CREATED:  2007-11-05
# MODIFIED: 2007-11-09

require 'FileUtils'
require 'uri'
require 'erb'

DEBUG = false
DEFAULT_FORMAT = (ENV['WIKI_PAGE_FORMAT'] || 'maruku').intern

# The class that handles interaction with the wiki through TextMate
class PlainTextWiki
  attr_reader :wiki
  
  # Get the location of the header.rhtml, footer.rhtml and index.txt templates.
  def PlainTextWiki.templates_dir
    ENV['WIKI_TEMPLATE_DIR'] || "#{ENV['TM_BUNDLE_SUPPORT']}/templates"
  end
  
  def PlainTextWiki.create_new_wiki
      # Ask the user for a new wiki directory, exiting if cancelled
      cocoadialog = "#{ENV['TM_SUPPORT_PATH']}/bin/CocoaDialog.app/Contents/MacOS/CocoaDialog"
      dir = `#{cocoadialog} fileselect --text "Choose a directory for your new wiki (index.txt will be created automatically)" --select-only-directories`.strip
      exit if dir.empty?

      # Exit if index.txt already exists
      if File.file?("#{dir}/index.txt")
      	puts "index.txt already exists here"
      	exit 206
      end

      # Create and populate the index page by copying it from templates
      # Copy from the user specified directory if it exists or the bundle 
      # otherwise
      wiki = PlainTextWiki.new(dir)
      if File.exists?("#{templates_dir}/index.txt")
        FileUtils.copy("#{templates_dir}/index.txt", "#{dir}/index.txt")
      else
        FileUtils.copy("#{ENV['TM_BUNDLE_SUPPORT']}/templates/index.txt", "#{dir}/index.txt")
      end
      
      # Open this wiki in a project window
      `open -a TextMate "#{dir}"`
      
      # Select the index page
      wiki.go_to_index_page
  end

  def initialize(dir)
    # Exit unless dir is set (usually from ENV['TM_DIRECTORY'])
    # The TextMate command will demand that the file is saved (and so the
    # directory will be set), but it's best to double check given the
    # failure mode
    unless dir
      puts "Save this file first."
      exit 206
    end
    
    @wiki = Wiki.new(dir)
  end

  # Write out a list of all the pages.
  def linked_page_list
      wiki.pages.map { |p| "* [[#{p.full_name}]]" }.join("\n")
  end

  # Extract the name of the page under the caret and have TextMate open it.
  def follow_link
     if ENV['TM_SCOPE'].include?('markup.other.pagename.delimited')
      	idx = ENV['TM_LINE_INDEX'].to_i
      	pagename = (((ENV['TM_CURRENT_LINE'][0..idx-1] || "").reverse)[/^[^\[]*/] || "").reverse + ENV['TM_CURRENT_LINE'][idx..-1][/^[^\]]*/]
      	if /^\s*(.+?)(\s?\|\s?(.+?))\s*$/ =~ pagename
      	  pagename = $1
      	end
      else
      	pagename = ENV['TM_CURRENT_WORD']
      end
      
      go_to pagename
  end

  # Have TextMate open the index page.
  def go_to_index_page
      go_to "index"
  end

  # Have TextMate open the named page.
  def go_to(name)
    page = wiki.find(name)
    
    # Touch the file if it doesn't exist
    if page.nil?
      page = Page.new(name)
      FileUtils.touch_p(wiki.path(page))

      # switch away from TextMate and back to refresh the project drawer
      `osascript -e 'tell application "Dock" to activate'; osascript -e 'tell application "TextMate" to activate'`
    end

    `open "txmt://open/?url=file://#{URI.escape(wiki.path(page), Regexp.new("[^#{URI::PATTERN::UNRESERVED}]"))}"`
  end
  
  # Query the user for an output directory then export pages as HTML
  def export_as_html
      # dialogs
      cocoadialog = "#{ENV['TM_SUPPORT_PATH']}/bin/CocoaDialog.app/Contents/MacOS/CocoaDialog"
      export_dir_dialog = %Q[#{cocoadialog} fileselect --text "Choose a directory for wiki export" --select-only-directories]
      replace_dialog = %Q[#{cocoadialog} msgbox --text "Export will replace files" --icon "x" --informative-text "There are files in the way in the export directory. They will be lost if you continue." --button1 "Cancel Export" --button2 "Replace All"]

      # Ask the user for an export directory, exiting if cancelled
      export_dir = `#{export_dir_dialog}`.strip
      exit if export_dir.empty?

      # Export each file, check for clashes and asking user what to do
      exporter = HtmlExporter.new(export_dir, PlainTextWiki.templates_dir)
      if exporter.clash?(wiki)
        res = `#{replace_dialog}`.strip
        unless res == '2'
            puts res
            puts "Cancelled Export Wiki as HTML"
            exit 206
        end
      end
      
      # Write them out!
      exporter.export_all(wiki)

      # Open the exported wiki in the default HTML viewer
      `open #{export_dir}/index.html`
  end
  
end

# A Page is the atomic unit of wiki-ness.
# Pages are constructed through a name which is of the form `section/name`.
# The section is used to create namespaces within a wiki.
# Each page is then associated with an key, a lowercase, spaceless version
# of its name.
class Page
  attr_reader :section, :name, :format, :properties

  # Default extension for wiki page files
  def Page.extension; '.txt'; end

  # Constructs a canonical representation for a string
  def Page.make_key(name)
    name.downcase.tr(' ', '_').gsub('./', '')
  end

  # Creates a new page from the given name
  def initialize(pagename)
    @name = File.basename(pagename, Page.extension)
    @section = File.dirname(pagename)
    @format = DEFAULT_FORMAT
    @properties = {}
    load_properties
  end

  # Returns the section (if necessary) and name of this page
  def full_name
    ( section == '.' ? '' : "#{section}/") + name
  end

  def section_list
    section.split('/').map { |s| s == '.' ? 'home' : s }    
  end

  # A canonical id for this page (including section)
  def key; Page.make_key(section + '/' + name); end
  
  # Where does this Page reside on disk?
  def file; "#{section}/#{name}#{Page.extension}"; end

  # Page properties that can be used in templates
  def title; properties['title'] || name.gsub(/\b\w/){$&.upcase}; end
  def modified; File.exists?(file) ? File.mtime(file) : 'Not Saved'; end
  def path_to_root; (section + '/').gsub(/[^.\/]+\//, '../'); end
  
  # A simple text representation of a page (for debugging)
  def to_s
    "Page: {:name => #{name}, :section => #{section}, :key => #{key}, :modified => #{modified}}"
  end

  def load_properties
    if File.exists? file
      File.open(file, 'r').each_line { |line|
        if line =~ /^<!--\s*(\w+)\s*=\s*(.+)\s*-->\s*$/
          properties[$1] = $2
        else
          break
        end
      }
    end
  end
  
  # Used to get the context of the page for use in the ERB templates
  def vars
    return binding
  end
end

# This is the main Wiki class, basically a collection of Pages.
class Wiki
    # set by the initializer, passed in
    attr_reader :dir

    def initialize(dir)
        @dir = dir
        @pages = {}
                
        load_pages        
    end
    
    # All wiki pages
    def pages
      @pages.values
    end

    # Test for inclusion by lowercase name
    def find(name)
      print "<li>FIND #{Page.make_key(name)}</li>" if DEBUG
      @pages[Page.make_key(name)]
    end

    # Is there a page with the given name/key?
    def exists?(name)
      not find(name).nil?
    end

    def path(page)
      "#{dir}/#{page.file}"
    end

    def load_pages(section = '.')
      path = "#{dir}/#{section}"
      print "LOADING PAGES IN #{path}<br/>\n" if DEBUG
      
      File.exists?(path) and Dir.entries(path).each do |fn|
        filename = "#{path}/#{fn}"
        if File.directory?(filename) 
          load_pages("#{section}/#{fn}") unless (/^\./ === fn)
        elsif File.extname(fn) == Page.extension
          page = Page.new("#{section}/#{fn}")
          @pages[page.key] = page
          print "LOADED: #{page.key}<br/>\n" if DEBUG
        end
      end
    end
end

# Converts a wiki into a collection of web pages
class HtmlExporter
  attr_reader :export_dir, :templates_dir
  
  def initialize(export_dir, templates_dir)
    @export_dir   = export_dir
    @templates_dir = templates_dir
  end
  
  # The templates for exporting to HTML
  def header; open("#{templates_dir}/header.rhtml", "r").read; end
  def footer; open("#{templates_dir}/footer.rhtml", "r").read; end
  def stylesheet; "#{templates_dir}/wiki.css"; end
  
  # Adds format-appropriate links to the text from the given page, 
  # relative to the page
  def with_html_links(page, wiki)    
    rawpage  = open("#{wiki.dir}/#{page.file}", 'r').read
    
    # Only converts [[bracketed links]] as the others were interfering with
    # Markdown
    rawpage.gsub( /(\[\[(.+?)(\s?\|\s?(.+?))?\]\])/x ) do |m|
      match, name, extra, text = $1, $2, $3, $4
      if match
        # Otherwise try to convert the wiki link
        text ||= name
              
        # Deal with absolute vs relative paths
        if name.starts_with?('/')
          dest = wiki.find(name[1..-1])
          href = page.path_to_root + link(dest)        
        else
          dest = wiki.find(page.section + '/' + name)
          href = link(dest, page)
        end
      
        # Convert the href address into the correct format
        if href
          print "<li>Linking #{$1} in #{page.key} to #{dest.key}</li>"
          case page.format
            # Note: a space is inserted before a wiki link to prevent Markdown
            # confusion when a [link]() starts a line.
            when :maruku
              %Q[ [#{text}](#{href}){:.wiki}]
            when :markdown
              %Q[ [#{text}](#{href})]
            when :textile
              %Q[ "#{text}":#{href}]
          end
        else
          print "<li><strong>Warning</strong>: No page found for <tt>#{name}</tt></li>"
          text
        end
      end
    end
  end

  # Compute what the relative URL from from_page to to_page
  def link(to_page, from_page = nil)
    if ignore? to_page
      nil
    elsif from_page and to_page.section.starts_with?(from_page.section)
      path = Page.make_key(from_page.section) + '/'
      to_page.key.sub(path, '') + '.html'
    else
      to_page.key + '.html'
    end
  end

  # Work out which transform to use for this given page and return it 
  # as a proc along with its name
  def transform(page)
    format = page.format
    
    if format == :maruku
      begin
        require 'rubygems'
        require 'maruku'
        transform = Proc.new { |s| Maruku.new(s).to_html }
      rescue LoadError
        format = :markdown
      end     
    end   
    
    case format
      when :markdown
        require "#{ENV['TM_SUPPORT_PATH']}/lib/bluecloth.rb"
        require "#{ENV['TM_SUPPORT_PATH']}/lib/rubypants.rb"
        transform = Proc.new { |s| RubyPants.new(BlueCloth.new(s).to_html).to_html }
      when :textile
        require "#{ENV['TM_SUPPORT_PATH']}/lib/redcloth.rb"
        transform = Proc.new { |s| RedCloth.new(s).to_html }
    end
    
    return transform, format.to_s.capitalize
  end
  
  # Exports a single page from the given wiki doing the relevant substituion
  # into the header and footer.
  # Argument page is assumed to be non-nil. 
  def export(page, wiki)
    transform, transform_name = transform(page)
    print "<li>Exporting <tt>#{page.file}</tt> to #{link(page)} (#{transform_name})</li>\n"

    linktext = with_html_links(page, wiki)
    html = transform.call(linktext)

    out = export_dir + '/' + link(page)
    FileUtils.touch_p(out)
    File.open(out, 'w') do |fh|
      fh.puts(ERB.new(header).result(page.vars))
      fh.puts(html)
      fh.puts(ERB.new(footer).result(page.vars))
    end
  end

  # Check if any files will be overwritten
  def clash?(wiki)
    wiki.pages.any? { |p| link(p) and File.file?(export_dir + '/' + link(p)) }
  end

  def excluded_dirs
    "#{ENV['WIKI_EXPORT_EXCLUDE']}".split(',').map { |name| name.strip } + ['.svn']
  end

  def ignore?(page)
    page.nil? || excluded_dirs.any? {|d| page.section.include? d }
  end

  # Write out the entire wiki as HTML
  def export_all(wiki)
    print "<h1>Exporting to HTML</h1>"

    print "<p>Destination: <tt>#{export_dir}</tt></p>\n"    
    print "<p>Templates from: <tt>#{templates_dir}</tt></p>\n"

    print "<ul>"
    if File.exists? stylesheet
      print "<li>Copying stylesheet from #{stylesheet}</li>\n"
      FileUtils.copy(stylesheet, export_dir)
    end
    
    wiki.pages.each do |page|
      if ignore? page
        print "<li>Ignoring page #{page.key}</li>\n"
      else
        export(page, wiki)
      end
    end
    print "</ul>"
    
    print "<p><em>Export complete!</em></p>"
  end
end

# Creates a new file and all its directories
def FileUtils.touch_p(path)
  FileUtils.mkpath(File.dirname(path))
  FileUtils.touch(path)
end

# Useful extra method on strings
class String
  def starts_with?(prefix)
    index(prefix) == 0
  end
  
  def ends_with?(suffix)
    index(suffix) == length - suffix.length
  end
end